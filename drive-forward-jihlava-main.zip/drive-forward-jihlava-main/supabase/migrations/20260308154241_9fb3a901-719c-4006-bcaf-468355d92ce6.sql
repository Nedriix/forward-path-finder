-- Fix vehicles policies (recreate as permissive)
DROP POLICY "Public read vehicles" ON public.vehicles;
DROP POLICY "Admins insert vehicles" ON public.vehicles;
DROP POLICY "Admins update vehicles" ON public.vehicles;
DROP POLICY "Admins delete vehicles" ON public.vehicles;

CREATE POLICY "Public read vehicles" ON public.vehicles FOR SELECT USING (true);
CREATE POLICY "Admins insert vehicles" ON public.vehicles FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update vehicles" ON public.vehicles FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete vehicles" ON public.vehicles FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Fix announcements policies
DROP POLICY "Public read announcements" ON public.announcements;
DROP POLICY "Admins insert announcements" ON public.announcements;
DROP POLICY "Admins update announcements" ON public.announcements;
DROP POLICY "Admins delete announcements" ON public.announcements;

CREATE POLICY "Public read announcements" ON public.announcements FOR SELECT USING (true);
CREATE POLICY "Admins insert announcements" ON public.announcements FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update announcements" ON public.announcements FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete announcements" ON public.announcements FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Fix pricing_items policies
DROP POLICY "Public read pricing" ON public.pricing_items;
DROP POLICY "Admins insert pricing" ON public.pricing_items;
DROP POLICY "Admins update pricing" ON public.pricing_items;
DROP POLICY "Admins delete pricing" ON public.pricing_items;

CREATE POLICY "Public read pricing" ON public.pricing_items FOR SELECT USING (true);
CREATE POLICY "Admins insert pricing" ON public.pricing_items FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins update pricing" ON public.pricing_items FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete pricing" ON public.pricing_items FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- Fix storage policies
DROP POLICY "Admins can upload vehicle photos" ON storage.objects;
DROP POLICY "Admins can update vehicle photos" ON storage.objects;
DROP POLICY "Admins can delete vehicle photos" ON storage.objects;

CREATE POLICY "Admins can upload vehicle photos" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'vehicle-photos' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update vehicle photos" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'vehicle-photos' AND public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete vehicle photos" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'vehicle-photos' AND public.has_role(auth.uid(), 'admin'));